package com.ecoreport.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;

/**
 * Certificate Entity – issued when user reaches point thresholds.
 *
 * Thresholds:
 *   BRONZE: 50  points
 *   SILVER: 100 points
 *   GOLD:   200 points
 */
@Entity
@Table(name = "certificates")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Certificate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long certId;

    // FK → users
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private CertLevel certLevel;

    @Column(nullable = false)
    private int pointsAtIssue;

    @Column(nullable = false, unique = true, length = 50)
    private String uniqueCertId;

    private String qrCode;

    @Column(nullable = false, updatable = false)
    private LocalDateTime issuedAt = LocalDateTime.now();

    public enum CertLevel {
        BRONZE(50), SILVER(100), GOLD(200);

        private final int threshold;
        CertLevel(int threshold) { this.threshold = threshold; }
        public int getThreshold() { return threshold; }
    }
}
