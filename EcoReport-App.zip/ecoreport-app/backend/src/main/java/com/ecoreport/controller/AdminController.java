package com.ecoreport.controller;

import com.ecoreport.model.Report;
import com.ecoreport.model.Report.*;
import com.ecoreport.repository.UserRepository;
import com.ecoreport.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * AdminController – admin-only endpoints.
 *
 * All routes are protected by @PreAuthorize("hasRole('ADMIN')")
 * and additionally restricted in SecurityConfig (/api/admin/**).
 *
 * Routes:
 *   GET    /api/admin/reports           → FR-05 View all reports
 *   PUT    /api/admin/reports/{id}      → FR-06 Update report status
 *   GET    /api/admin/dashboard/stats   → Dashboard KPIs
 */
@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    @Autowired private ReportService reportService;
    @Autowired private UserRepository userRepository;

    /**
     * FR-05: Get all reports with optional status filter.
     * Reports are sorted by priority (URGENT first) then date.
     */
    @GetMapping("/reports")
    public ResponseEntity<?> getAllReports(
            @RequestParam(required = false) String status) {
        try {
            List<Report> reports;
            if (status != null) {
                reports = reportService.getReportsByStatus(ReportStatus.valueOf(status.toUpperCase()));
            } else {
                reports = reportService.getAllReports();
            }
            return ResponseEntity.ok(reports.stream().map(this::toMap).toList());
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * FR-06 + FR-08: Update status, priority, and validity.
     * If isValid=true, points are automatically awarded via PointsService.
     */
    @PutMapping("/reports/{id}")
    public ResponseEntity<?> updateReport(
            @PathVariable Long id,
            @RequestBody Map<String, Object> body,
            @AuthenticationPrincipal UserDetails userDetails) {
        try {
            Long adminId = userRepository.findByEmail(userDetails.getUsername())
                .orElseThrow().getUserId();

            ReportStatus status = body.containsKey("status")
                ? ReportStatus.valueOf(body.get("status").toString().toUpperCase())
                : null;

            Priority priority = body.containsKey("priority")
                ? Priority.valueOf(body.get("priority").toString().toUpperCase())
                : null;

            Boolean isValid = body.containsKey("isValid")
                ? (Boolean) body.get("isValid")
                : null;

            Report updated = reportService.updateStatus(id, status, priority, isValid, adminId);
            return ResponseEntity.ok(toMap(updated));

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * FR-05: Dashboard statistics for admin KPIs.
     * Returns counts: total, pending, inProgress, resolved, urgent.
     */
    @GetMapping("/dashboard/stats")
    public ResponseEntity<?> getDashboardStats() {
        return ResponseEntity.ok(reportService.getDashboardStats());
    }

    private Map<String, Object> toMap(Report r) {
        return Map.of(
            "reportId",      r.getReportId(),
            "userId",        r.getUser().getUserId(),
            "userName",      r.getUser().getName(),
            "incidentType",  r.getIncidentType().name(),
            "description",   r.getDescription(),
            "location",      r.getLocation(),
            "status",        r.getStatus().name(),
            "priority",      r.getPriority().name(),
            "pointsAwarded", r.getPointsAwarded(),
            "submittedAt",   r.getSubmittedAt().toString()
        );
    }
}
