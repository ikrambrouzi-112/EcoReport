package com.ecoreport.controller;

import com.ecoreport.model.Certificate;
import com.ecoreport.repository.CertificateRepository;
import com.ecoreport.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * CertificateController – handles FR-09 (View Points and Certificates).
 *
 * Routes:
 *   GET /api/certificates/my              → Get user's certificates
 *   GET /api/certificates/verify/{certId} → Public QR code verification
 */
@RestController
@RequestMapping("/api/certificates")
public class CertificateController {

    @Autowired private CertificateRepository certRepository;
    @Autowired private UserRepository userRepository;

    /**
     * FR-09: Get all certificates for the authenticated user.
     */
    @GetMapping("/my")
    public ResponseEntity<?> getMyCertificates(
            @AuthenticationPrincipal UserDetails userDetails) {
        try {
            Long userId = userRepository.findByEmail(userDetails.getUsername())
                .orElseThrow().getUserId();

            List<Certificate> certs = certRepository.findByUserUserIdOrderByIssuedAtDesc(userId);
            return ResponseEntity.ok(certs.stream().map(this::toMap).toList());

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * FR-09: Public endpoint for verifying a certificate via QR code.
     * No authentication required.
     */
    @GetMapping("/verify/{certId}")
    public ResponseEntity<?> verifyCertificate(@PathVariable String certId) {
        return certRepository.findByUniqueCertId(certId)
            .map(cert -> ResponseEntity.ok(Map.of(
                "valid",     true,
                "certId",    cert.getUniqueCertId(),
                "level",     cert.getCertLevel().name(),
                "holder",    cert.getUser().getName(),
                "issuedAt",  cert.getIssuedAt().toString(),
                "points",    cert.getPointsAtIssue()
            )))
            .orElse(ResponseEntity.ok(Map.of("valid", false, "message", "Certificate not found")));
    }

    /** Get points and certificate info for the current user */
    @GetMapping("/my/summary")
    public ResponseEntity<?> getSummary(
            @AuthenticationPrincipal UserDetails userDetails) {
        try {
            var user = userRepository.findByEmail(userDetails.getUsername()).orElseThrow();
            var certs = certRepository.findByUserUserIdOrderByIssuedAtDesc(user.getUserId());

            return ResponseEntity.ok(Map.of(
                "totalPoints",   user.getTotalPoints(),
                "certificates",  certs.stream().map(this::toMap).toList(),
                "nextLevel",     getNextLevel(user.getTotalPoints()),
                "pointsNeeded",  getPointsNeeded(user.getTotalPoints())
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    private String getNextLevel(int points) {
        if (points < 50) return "BRONZE";
        if (points < 100) return "SILVER";
        if (points < 200) return "GOLD";
        return "MAX";
    }

    private int getPointsNeeded(int points) {
        if (points < 50) return 50 - points;
        if (points < 100) return 100 - points;
        if (points < 200) return 200 - points;
        return 0;
    }

    private Map<String, Object> toMap(Certificate c) {
        return Map.of(
            "certId",       c.getCertId(),
            "uniqueCertId", c.getUniqueCertId(),
            "certLevel",    c.getCertLevel().name(),
            "pointsAtIssue",c.getPointsAtIssue(),
            "issuedAt",     c.getIssuedAt().toString(),
            "qrCode",       c.getQrCode() != null ? c.getQrCode() : ""
        );
    }
}
