package com.ecoreport.repository;

import com.ecoreport.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * UserRepository – Repository Pattern implementation.
 *
 * Extends JpaRepository to get free CRUD operations:
 *   save(), findById(), findAll(), delete(), count(), ...
 *
 * Custom queries are declared as method signatures
 * and Spring Data JPA generates the SQL automatically.
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    /** Find user by email (used for login authentication) */
    Optional<User> findByEmail(String email);

    /** Check if an email already exists (used during registration) */
    boolean existsByEmail(String email);
}
