package com.ecoreport.repository;

import com.ecoreport.model.Report;
import com.ecoreport.model.Report.ReportStatus;
import com.ecoreport.model.Report.Priority;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * ReportRepository – Repository Pattern for Report data access.
 *
 * Spring Data JPA auto-implements queries from method names.
 * Custom @Query annotations use JPQL (Java Persistence Query Language).
 */
@Repository
public interface ReportRepository extends JpaRepository<Report, Long> {

    /** Get all reports submitted by a specific user */
    List<Report> findByUserUserIdOrderBySubmittedAtDesc(Long userId);

    /** Get all reports with a given status (for admin filtering) */
    List<Report> findByStatusOrderBySubmittedAtDesc(ReportStatus status);

    /** Get all reports with a given priority */
    List<Report> findByPriorityOrderBySubmittedAtDesc(Priority priority);

    /** Get urgent/fire reports that need immediate attention */
    List<Report> findByPriorityAndStatusNot(Priority priority, ReportStatus status);

    /** Count reports by status (for admin dashboard KPIs) */
    long countByStatus(ReportStatus status);

    /** Count urgent reports */
    long countByPriority(Priority priority);

    /** Custom JPQL: search reports by location keyword */
    @Query("SELECT r FROM Report r WHERE LOWER(r.location) LIKE LOWER(CONCAT('%', :location, '%'))")
    List<Report> findByLocationContaining(@Param("location") String location);

    /** Admin: get all reports ordered by urgency then date */
    @Query("SELECT r FROM Report r ORDER BY " +
           "CASE r.priority WHEN 'URGENT' THEN 1 WHEN 'HIGH' THEN 2 WHEN 'MEDIUM' THEN 3 ELSE 4 END, " +
           "r.submittedAt DESC")
    List<Report> findAllOrderedByPriority();
}
