package com.ecoreport.dto;

import jakarta.validation.constraints.*;
import lombok.Data;
import com.ecoreport.model.Report;

/**
 * DTOs – Data Transfer Objects
 *
 * DTOs are used to separate the API contract from the internal domain model.
 * They carry only what the client needs to send/receive.
 * Validation annotations enforce FR-03 rules.
 */

// ── Auth DTOs ─────────────────────────────────────────────────────────────

class LoginRequest {
    @NotBlank @Email
    public String email;

    @NotBlank @Size(min = 6)
    public String password;
}

class RegisterRequest {
    @NotBlank @Size(min = 2, max = 100)
    public String name;

    @NotBlank @Email
    public String email;

    @NotBlank @Size(min = 6)
    public String password;
}

class AuthResponse {
    public String token;
    public String name;
    public String email;
    public String role;
    public int totalPoints;

    public AuthResponse(String token, String name, String email, String role, int totalPoints) {
        this.token = token;
        this.name = name;
        this.email = email;
        this.role = role;
        this.totalPoints = totalPoints;
    }
}

// ── Report DTOs ───────────────────────────────────────────────────────────

class ReportRequest {
    @NotNull
    public Report.IncidentType incidentType;

    @NotBlank @Size(min = 10, max = 500) // FR-03: min 10, max 500 chars
    public String description;

    @NotBlank
    public String location;

    public Double latitude;
    public Double longitude;

    public Report.Priority priority;
}

class StatusUpdateRequest {
    @NotNull
    public Report.ReportStatus status;

    public Report.Priority priority;

    public Boolean isValid; // FR-08: marks report valid/invalid for points
}
