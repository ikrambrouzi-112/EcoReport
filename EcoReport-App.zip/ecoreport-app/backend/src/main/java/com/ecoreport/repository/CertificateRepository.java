package com.ecoreport.repository;

import com.ecoreport.model.Certificate;
import com.ecoreport.model.Certificate.CertLevel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * CertificateRepository – data access for certificates.
 */
@Repository
public interface CertificateRepository extends JpaRepository<Certificate, Long> {

    /** Get all certificates for a user */
    List<Certificate> findByUserUserIdOrderByIssuedAtDesc(Long userId);

    /** Check if user already has a specific certificate level */
    boolean existsByUserUserIdAndCertLevel(Long userId, CertLevel certLevel);

    /** Find certificate by its unique ID (for QR verification) */
    Optional<Certificate> findByUniqueCertId(String uniqueCertId);
}
