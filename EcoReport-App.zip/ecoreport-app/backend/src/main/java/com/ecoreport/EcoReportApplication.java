package com.ecoreport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * EcoReport – Main Application Entry Point
 *
 * Public Infrastructure & Fire Incident Reporting System
 * Province of Ifrane
 */
@SpringBootApplication
public class EcoReportApplication {

    public static void main(String[] args) {
        SpringApplication.run(EcoReportApplication.class, args);
        System.out.println("""
            ╔══════════════════════════════════════╗
            ║      EcoReport Server Started        ║
            ║  http://localhost:8080               ║
            ║  API: http://localhost:8080/api      ║
            ╚══════════════════════════════════════╝
            """);
    }
}
