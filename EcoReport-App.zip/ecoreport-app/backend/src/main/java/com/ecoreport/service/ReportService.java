package com.ecoreport.service;

import com.ecoreport.model.Report;
import com.ecoreport.model.Report.*;
import com.ecoreport.model.User;
import com.ecoreport.repository.ReportRepository;
import com.ecoreport.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.util.List;
import java.util.UUID;

/**
 * ReportService – business logic for report submission and management.
 *
 * Implements:
 *   FR-03: Submit Incident Report
 *   FR-04: View Report Status
 *   FR-06: Update Report Status
 *   FR-07: Prioritize Urgent Reports
 *   FR-10: Location Validation (Ifrane region boundary check)
 */
@Service
public class ReportService {

    @Autowired private ReportRepository reportRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private PointsService pointsService;

    @Value("${app.upload.dir}")
    private String uploadDir;

    // ── Ifrane region bounding box (FR-10) ──
    private static final double LAT_MIN = 33.45;
    private static final double LAT_MAX = 33.62;
    private static final double LNG_MIN = -5.22;
    private static final double LNG_MAX = -5.01;

    /**
     * FR-03: Submit a new report with location validation.
     * Auto-assigns Report ID, sets status to PENDING.
     */
    @Transactional
    public Report submitReport(Long userId,
                               IncidentType type,
                               String description,
                               String location,
                               Double latitude,
                               Double longitude,
                               Priority priority,
                               MultipartFile image) throws IOException {

        // FR-10: Validate location is within Ifrane region
        if (latitude != null && longitude != null) {
            if (!isInIfraneRegion(latitude, longitude)) {
                throw new RuntimeException("Location is outside the Ifrane region. " +
                    "Only reports within Ifrane Province are accepted.");
            }
        }

        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found"));

        Report report = new Report();
        report.setUser(user);
        report.setIncidentType(type);
        report.setDescription(description);
        report.setLocation(location);
        report.setLatitude(latitude);
        report.setLongitude(longitude);
        report.setStatus(ReportStatus.PENDING);
        report.setPriority(priority != null ? priority : Priority.MEDIUM);

        // Auto-set fire hazards as URGENT (FR-07)
        if (type == IncidentType.FIRE_HAZARD) {
            report.setPriority(Priority.URGENT);
        }

        // Handle optional image upload
        if (image != null && !image.isEmpty()) {
            String imagePath = saveImage(image);
            report.setImagePath(imagePath);
        }

        return reportRepository.save(report);
    }

    /** FR-04: Get all reports for a specific user */
    public List<Report> getUserReports(Long userId) {
        return reportRepository.findByUserUserIdOrderBySubmittedAtDesc(userId);
    }

    /** Get all reports (admin) */
    public List<Report> getAllReports() {
        return reportRepository.findAllOrderedByPriority();
    }

    /** Get reports filtered by status */
    public List<Report> getReportsByStatus(ReportStatus status) {
        return reportRepository.findByStatusOrderBySubmittedAtDesc(status);
    }

    /**
     * FR-06: Admin updates report status with audit trail.
     * FR-08: If marked valid, award points to user.
     */
    @Transactional
    public Report updateStatus(Long reportId, ReportStatus status,
                               Priority priority, Boolean isValid, Long adminId) {
        Report report = reportRepository.findById(reportId)
            .orElseThrow(() -> new RuntimeException("Report not found: " + reportId));

        User admin = userRepository.findById(adminId)
            .orElseThrow(() -> new RuntimeException("Admin not found"));

        report.setStatus(status);
        if (priority != null) report.setPriority(priority);
        report.setUpdatedBy(admin);

        // FR-08: Award points when admin marks report as valid
        if (isValid != null && isValid && report.getIsValid() == null) {
            report.setIsValid(true);
            pointsService.awardPoints(report.getUser(), report);
        } else if (isValid != null && !isValid) {
            report.setIsValid(false);
        }

        return reportRepository.save(report);
    }

    /** Get report by ID */
    public Report getReportById(Long reportId) {
        return reportRepository.findById(reportId)
            .orElseThrow(() -> new RuntimeException("Report not found: " + reportId));
    }

    /** Dashboard KPIs for admin */
    public java.util.Map<String, Long> getDashboardStats() {
        java.util.Map<String, Long> stats = new java.util.HashMap<>();
        stats.put("total", reportRepository.count());
        stats.put("pending", reportRepository.countByStatus(ReportStatus.PENDING));
        stats.put("inProgress", reportRepository.countByStatus(ReportStatus.IN_PROGRESS));
        stats.put("resolved", reportRepository.countByStatus(ReportStatus.RESOLVED));
        stats.put("urgent", reportRepository.countByPriority(Priority.URGENT));
        return stats;
    }

    // ── Private Helpers ──────────────────────────────────────────────────

    /** FR-10: Check if coordinates are within Ifrane Province boundary box */
    private boolean isInIfraneRegion(double lat, double lng) {
        return lat >= LAT_MIN && lat <= LAT_MAX &&
               lng >= LNG_MIN && lng <= LNG_MAX;
    }

    /** Save uploaded image to disk, return relative path */
    private String saveImage(MultipartFile file) throws IOException {
        Path dir = Paths.get(uploadDir);
        if (!Files.exists(dir)) Files.createDirectories(dir);

        String fileName = UUID.randomUUID() + "_" + file.getOriginalFilename();
        Path path = dir.resolve(fileName);
        Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);

        return fileName;
    }
}
