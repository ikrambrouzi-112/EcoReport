package com.ecoreport.service;

import com.ecoreport.model.User;
import com.ecoreport.repository.UserRepository;
import com.ecoreport.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * AuthService – handles registration and login business logic.
 *
 * Implements FR-01 (Registration) and FR-02 (Login).
 */
@Service
public class AuthService {

    @Autowired private UserRepository userRepository;
    @Autowired private PasswordEncoder passwordEncoder;
    @Autowired private JwtUtil jwtUtil;
    @Autowired private AuthenticationManager authManager;
    @Autowired private UserDetailsService userDetailsService;

    /**
     * FR-01: Register a new citizen account.
     * Validates that email is not already taken.
     */
    public Map<String, Object> register(String name, String email, String password) {
        if (userRepository.existsByEmail(email)) {
            throw new RuntimeException("Email already registered.");
        }

        // Hash password with BCrypt before saving (NFR-03 Security)
        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setPasswordHash(passwordEncoder.encode(password));
        user.setRole(User.Role.CITIZEN);
        user.setTotalPoints(0);

        userRepository.save(user);

        // Generate and return JWT token
        UserDetails userDetails = userDetailsService.loadUserByUsername(email);
        String token = jwtUtil.generateToken(userDetails);

        return buildResponse(user, token);
    }

    /**
     * FR-02: Authenticate a user and return a JWT token.
     * Spring Security's AuthenticationManager handles credential verification.
     */
    public Map<String, Object> login(String email, String password) {
        // This throws BadCredentialsException if wrong password
        authManager.authenticate(
            new UsernamePasswordAuthenticationToken(email, password));

        User user = userRepository.findByEmail(email)
            .orElseThrow(() -> new RuntimeException("User not found"));

        UserDetails userDetails = userDetailsService.loadUserByUsername(email);
        String token = jwtUtil.generateToken(userDetails);

        return buildResponse(user, token);
    }

    private Map<String, Object> buildResponse(User user, String token) {
        Map<String, Object> response = new HashMap<>();
        response.put("token", token);
        response.put("userId", user.getUserId());
        response.put("name", user.getName());
        response.put("email", user.getEmail());
        response.put("role", user.getRole().name());
        response.put("totalPoints", user.getTotalPoints());
        return response;
    }
}
