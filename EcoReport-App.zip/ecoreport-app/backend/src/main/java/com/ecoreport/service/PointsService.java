package com.ecoreport.service;

import com.ecoreport.model.Certificate;
import com.ecoreport.model.Certificate.CertLevel;
import com.ecoreport.model.PointsTransaction;
import com.ecoreport.model.Report;
import com.ecoreport.model.User;
import com.ecoreport.repository.CertificateRepository;
import com.ecoreport.repository.PointsTransactionRepository;
import com.ecoreport.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

/**
 * PointsService – implements FR-08 and FR-09.
 *
 * Implements the Observer pattern:
 *   When a report is validated → award points → check certificate thresholds.
 *
 * Certificate thresholds (FR-09):
 *   BRONZE: >= 50  points
 *   SILVER: >= 100 points
 *   GOLD:   >= 200 points
 */
@Service
public class PointsService {

    private static final int POINTS_PER_VALID_REPORT = 10;

    @Autowired private UserRepository userRepository;
    @Autowired private CertificateRepository certRepository;
    @Autowired private PointsTransactionRepository txRepository;

    /**
     * FR-08: Award points to user for a validated report.
     * Also checks and issues certificates if thresholds are reached.
     */
    @Transactional
    public void awardPoints(User user, Report report) {
        // Award points
        int newTotal = user.getTotalPoints() + POINTS_PER_VALID_REPORT;
        user.setTotalPoints(newTotal);
        report.setPointsAwarded(POINTS_PER_VALID_REPORT);
        userRepository.save(user);

        // Log the points transaction (audit trail)
        PointsTransaction tx = new PointsTransaction();
        tx.setUser(user);
        tx.setReport(report);
        tx.setPoints(POINTS_PER_VALID_REPORT);
        tx.setReason("Valid incident report submitted");
        txRepository.save(tx);

        // FR-09: Check certificate thresholds
        checkAndIssueCertificate(user, newTotal);
    }

    /**
     * FR-09: Issue a certificate if the user crossed a threshold.
     * Each level is issued only once per user.
     */
    private void checkAndIssueCertificate(User user, int totalPoints) {
        for (CertLevel level : new CertLevel[]{CertLevel.GOLD, CertLevel.SILVER, CertLevel.BRONZE}) {
            if (totalPoints >= level.getThreshold() &&
                !certRepository.existsByUserUserIdAndCertLevel(user.getUserId(), level)) {

                Certificate cert = new Certificate();
                cert.setUser(user);
                cert.setCertLevel(level);
                cert.setPointsAtIssue(totalPoints);
                cert.setUniqueCertId(generateCertId(level));
                cert.setQrCode("https://ecoreport.ifrane.ma/verify/" + cert.getUniqueCertId());

                certRepository.save(cert);

                // In a real system: send email with PDF certificate here
                System.out.printf("🎓 Certificate issued: %s → %s%n",
                    user.getName(), level.name());
                break; // Only issue highest new certificate
            }
        }
    }

    /** Generate a human-readable unique certificate ID */
    private String generateCertId(CertLevel level) {
        return String.format("CERT-%d-%s-%s",
            java.time.Year.now().getValue(),
            level.name().substring(0, 2),
            UUID.randomUUID().toString().substring(0, 6).toUpperCase());
    }
}
