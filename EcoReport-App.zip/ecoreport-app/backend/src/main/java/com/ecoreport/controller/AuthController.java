package com.ecoreport.controller;

import com.ecoreport.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * AuthController – REST endpoints for authentication.
 *
 * Routes:
 *   POST /api/auth/register  → FR-01 User Registration
 *   POST /api/auth/login     → FR-02 User Login
 *
 * Both are public (no JWT required) – configured in SecurityConfig.
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    /**
     * FR-01: Register a new user account.
     *
     * Request body: { name, email, password }
     * Response:     { token, userId, name, email, role, totalPoints }
     */
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Map<String, String> body) {
        try {
            String name     = body.get("name");
            String email    = body.get("email");
            String password = body.get("password");

            if (name == null || email == null || password == null) {
                return ResponseEntity.badRequest().body(Map.of("error", "name, email, and password are required"));
            }
            if (password.length() < 6) {
                return ResponseEntity.badRequest().body(Map.of("error", "Password must be at least 6 characters"));
            }

            Map<String, Object> response = authService.register(name, email, password);
            return ResponseEntity.ok(response);

        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * FR-02: Login with email and password.
     *
     * Request body: { email, password }
     * Response:     { token, userId, name, email, role, totalPoints }
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> body) {
        try {
            String email    = body.get("email");
            String password = body.get("password");

            if (email == null || password == null) {
                return ResponseEntity.badRequest().body(Map.of("error", "email and password are required"));
            }

            Map<String, Object> response = authService.login(email, password);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            return ResponseEntity.status(401).body(Map.of("error", "Invalid email or password"));
        }
    }
}
