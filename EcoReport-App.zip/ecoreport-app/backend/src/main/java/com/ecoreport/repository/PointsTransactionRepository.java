package com.ecoreport.repository;

import com.ecoreport.model.PointsTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PointsTransactionRepository extends JpaRepository<PointsTransaction, Long> {

    /** Get all point awards for a specific user */
    List<PointsTransaction> findByUserUserIdOrderByCreatedAtDesc(Long userId);
}
