package com.ecoreport.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;

/**
 * Report Entity – core domain object of the system.
 *
 * Represents a citizen-submitted incident report.
 * Status lifecycle: PENDING → IN_PROGRESS → RESOLVED
 */
@Entity
@Table(name = "reports")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Report {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long reportId;

    // FK to users table – Many reports belong to one user
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private IncidentType incidentType;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String description;

    @Column(nullable = false, length = 255)
    private String location;

    // GPS coordinates for map integration
    private Double latitude;
    private Double longitude;

    // Optional photo evidence path
    private String imagePath;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ReportStatus status = ReportStatus.PENDING;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Priority priority = Priority.MEDIUM;

    @Column(nullable = false)
    private int pointsAwarded = 0;

    // null = not yet reviewed, true = valid, false = invalid/duplicate
    private Boolean isValid;

    @Column(nullable = false, updatable = false)
    private LocalDateTime submittedAt = LocalDateTime.now();

    private LocalDateTime updatedAt = LocalDateTime.now();

    // Tracks which admin made the last update
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "updated_by")
    private User updatedBy;

    @PreUpdate
    public void preUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    // ── Enums ──────────────────────────────

    public enum IncidentType {
        WATER_LEAK, FIRE_HAZARD, INFRASTRUCTURE, OTHER
    }

    public enum ReportStatus {
        PENDING, IN_PROGRESS, RESOLVED
    }

    public enum Priority {
        LOW, MEDIUM, HIGH, URGENT
    }
}
