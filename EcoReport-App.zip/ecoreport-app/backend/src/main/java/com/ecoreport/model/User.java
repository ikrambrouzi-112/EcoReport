package com.ecoreport.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

/**
 * User Entity – represents both citizens and admins.
 * Uses RBAC (Role-Based Access Control) via the Role enum.
 *
 * Design Pattern: JPA Entity (part of Repository Pattern)
 */
@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(nullable = false, unique = true, length = 150)
    private String email;

    @Column(nullable = false)
    private String passwordHash;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role role = Role.CITIZEN;

    @Column(nullable = false)
    private int totalPoints = 0;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    private LocalDateTime updatedAt = LocalDateTime.now();

    // One user can have many reports
    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    private List<Report> reports;

    // One user can have many certificates
    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    private List<Certificate> certificates;

    @PreUpdate
    public void preUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    public enum Role {
        CITIZEN, ADMIN
    }
}
