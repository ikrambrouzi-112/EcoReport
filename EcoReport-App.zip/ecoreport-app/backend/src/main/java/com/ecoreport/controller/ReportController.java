package com.ecoreport.controller;

import com.ecoreport.model.Report;
import com.ecoreport.model.Report.*;
import com.ecoreport.model.User;
import com.ecoreport.repository.UserRepository;
import com.ecoreport.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

/**
 * ReportController – REST endpoints for incident reports.
 *
 * Routes:
 *   POST   /api/reports              → FR-03 Submit report
 *   GET    /api/reports/my           → FR-04 View own reports
 *   GET    /api/reports/{id}         → Get single report
 *
 * All routes require JWT authentication.
 */
@RestController
@RequestMapping("/api/reports")
public class ReportController {

    @Autowired private ReportService reportService;
    @Autowired private UserRepository userRepository;

    /**
     * FR-03: Submit a new incident report.
     *
     * Accepts multipart form data (supports image upload).
     * Validates location is within Ifrane region (FR-10).
     */
    @PostMapping(consumes = {"multipart/form-data", "application/json"})
    public ResponseEntity<?> submitReport(
            @AuthenticationPrincipal UserDetails userDetails,
            @RequestParam("incidentType")  String type,
            @RequestParam("description")   String description,
            @RequestParam("location")      String location,
            @RequestParam(value = "latitude",  required = false) Double latitude,
            @RequestParam(value = "longitude", required = false) Double longitude,
            @RequestParam(value = "priority",  required = false) String priority,
            @RequestParam(value = "image",     required = false) MultipartFile image) {

        try {
            Long userId = getUserId(userDetails);

            Report report = reportService.submitReport(
                userId,
                IncidentType.valueOf(type.toUpperCase()),
                description,
                location,
                latitude,
                longitude,
                priority != null ? Priority.valueOf(priority.toUpperCase()) : null,
                image
            );

            return ResponseEntity.ok(toMap(report));

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * FR-04: Get all reports submitted by the logged-in user.
     */
    @GetMapping("/my")
    public ResponseEntity<?> getMyReports(
            @AuthenticationPrincipal UserDetails userDetails) {
        try {
            Long userId = getUserId(userDetails);
            List<Report> reports = reportService.getUserReports(userId);
            return ResponseEntity.ok(reports.stream().map(this::toMap).toList());
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /** Get a single report by ID */
    @GetMapping("/{id}")
    public ResponseEntity<?> getReport(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(toMap(reportService.getReportById(id)));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────

    private Long getUserId(UserDetails userDetails) {
        return userRepository.findByEmail(userDetails.getUsername())
            .orElseThrow(() -> new RuntimeException("User not found"))
            .getUserId();
    }

    /** Convert Report entity to a clean JSON-friendly map */
    private Map<String, Object> toMap(Report r) {
        return Map.of(
            "reportId",      r.getReportId(),
            "incidentType",  r.getIncidentType().name(),
            "description",   r.getDescription(),
            "location",      r.getLocation(),
            "status",        r.getStatus().name(),
            "priority",      r.getPriority().name(),
            "pointsAwarded", r.getPointsAwarded(),
            "submittedAt",   r.getSubmittedAt().toString(),
            "imagePath",     r.getImagePath() != null ? r.getImagePath() : "",
            "isValid",       r.getIsValid() != null ? r.getIsValid() : false
        );
    }
}
