-- ─────────────────────────────────────────────
-- EcoReport – MySQL Database Schema
-- Run this script to create the database
-- ─────────────────────────────────────────────

CREATE DATABASE IF NOT EXISTS ecoreport_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE ecoreport_db;

-- ── Users ──────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  user_id       INT AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(100)  NOT NULL,
  email         VARCHAR(150)  NOT NULL UNIQUE,
  password_hash VARCHAR(255)  NOT NULL,
  role          ENUM('CITIZEN', 'ADMIN') NOT NULL DEFAULT 'CITIZEN',
  total_points  INT           NOT NULL DEFAULT 0,
  created_at    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ── Reports ────────────────────────────────
CREATE TABLE IF NOT EXISTS reports (
  report_id      INT AUTO_INCREMENT PRIMARY KEY,
  user_id        INT          NOT NULL,
  incident_type  ENUM('WATER_LEAK', 'FIRE_HAZARD', 'INFRASTRUCTURE', 'OTHER') NOT NULL,
  description    TEXT         NOT NULL,
  location       VARCHAR(255) NOT NULL,
  latitude       DECIMAL(10, 7),
  longitude      DECIMAL(10, 7),
  image_path     VARCHAR(500),
  status         ENUM('PENDING', 'IN_PROGRESS', 'RESOLVED') NOT NULL DEFAULT 'PENDING',
  priority       ENUM('LOW', 'MEDIUM', 'HIGH', 'URGENT')    NOT NULL DEFAULT 'MEDIUM',
  points_awarded INT          NOT NULL DEFAULT 0,
  is_valid       BOOLEAN,
  submitted_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  updated_by     INT,
  CONSTRAINT fk_report_user    FOREIGN KEY (user_id)    REFERENCES users(user_id),
  CONSTRAINT fk_report_updater FOREIGN KEY (updated_by) REFERENCES users(user_id)
);

-- ── Certificates ───────────────────────────
CREATE TABLE IF NOT EXISTS certificates (
  cert_id        INT AUTO_INCREMENT PRIMARY KEY,
  user_id        INT          NOT NULL,
  cert_level     ENUM('BRONZE', 'SILVER', 'GOLD') NOT NULL,
  points_at_issue INT         NOT NULL,
  unique_cert_id VARCHAR(50)  NOT NULL UNIQUE,
  qr_code        VARCHAR(255),
  issued_at      TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_cert_user FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- ── Points Transactions ────────────────────
CREATE TABLE IF NOT EXISTS points_transactions (
  tx_id       INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT  NOT NULL,
  report_id   INT  NOT NULL,
  points      INT  NOT NULL,
  reason      VARCHAR(255),
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_tx_user   FOREIGN KEY (user_id)   REFERENCES users(user_id),
  CONSTRAINT fk_tx_report FOREIGN KEY (report_id) REFERENCES reports(report_id)
);

-- ── Seed Data ─────────────────────────────
-- Admin user (password: admin123)
INSERT INTO users (name, email, password_hash, role, total_points)
VALUES ('Admin Ifrane', 'admin@ifrane.ma',
        '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', -- bcrypt of "admin123"
        'ADMIN', 0);

-- Sample citizen (password: citizen123)
INSERT INTO users (name, email, password_hash, role, total_points)
VALUES ('Sarah Alami', 'sarah@example.com',
        '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.',
        'CITIZEN', 120);

-- Sample reports
INSERT INTO reports (user_id, incident_type, description, location, latitude, longitude, status, priority, points_awarded, is_valid)
VALUES
  (2, 'WATER_LEAK',      'Large water leak on Al Akhawayn Avenue near the main gate.', 'Al Akhawayn Ave, Ifrane', 33.5333, -5.1167, 'PENDING',     'HIGH',   10, TRUE),
  (2, 'FIRE_HAZARD',     'Electrical sparks seen near the City Center generator room.', 'City Center, Ifrane',     33.5300, -5.1100, 'IN_PROGRESS', 'URGENT', 10, TRUE),
  (2, 'INFRASTRUCTURE',  'Deep pothole on the market road causing vehicle damage.',     'Market District, Ifrane', 33.5280, -5.1080, 'RESOLVED',    'MEDIUM', 10, TRUE),
  (2, 'WATER_LEAK',      'Broken pipe in Cedar Avenue causing flooding.',               'Cedar Ave, Ifrane',       33.5350, -5.1200, 'RESOLVED',    'HIGH',   10, TRUE);

-- Sample certificate
INSERT INTO certificates (user_id, cert_level, points_at_issue, unique_cert_id)
VALUES (2, 'BRONZE', 50, 'CERT-2026-BR-0042'),
       (2, 'SILVER', 100, 'CERT-2026-SL-0018');
