/**
 * api.js – centralized API communication layer.
 *
 * All HTTP requests to the Spring Boot backend go through here.
 * Automatically attaches the JWT token to every authenticated request.
 */

const API_BASE = 'http://localhost:8080/api';

/** Get the stored JWT token from localStorage */
function getToken() {
    return localStorage.getItem('ecoreport_token');
}

/** Check if user is authenticated */
function isAuthenticated() {
    return !!getToken();
}

/** Get current user info */
function getCurrentUser() {
    const data = localStorage.getItem('ecoreport_user');
    return data ? JSON.parse(data) : null;
}

/** Check if current user is admin */
function isAdmin() {
    const user = getCurrentUser();
    return user && user.role === 'ADMIN';
}

/**
 * Core fetch wrapper.
 * Attaches Authorization header, handles JSON parsing and errors.
 */
async function apiFetch(path, options = {}) {
    const token = getToken();
    const headers = {
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
        ...options.headers
    };

    const response = await fetch(`${API_BASE}${path}`, {
        ...options,
        headers
    });

    if (response.status === 401) {
        // Token expired – redirect to login
        logout();
        return;
    }

    const data = await response.json();

    if (!response.ok) {
        throw new Error(data.error || 'Request failed');
    }

    return data;
}

/** Multipart form fetch (for file uploads) */
async function apiFormFetch(path, formData) {
    const token = getToken();
    const response = await fetch(`${API_BASE}${path}`, {
        method: 'POST',
        headers: token ? { 'Authorization': `Bearer ${token}` } : {},
        body: formData
    });

    if (response.status === 401) {
        logout();
        return;
    }

    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Request failed');
    return data;
}

// ── Auth API ──────────────────────────────────────────────────────────

/** FR-01: Register */
async function apiRegister(name, email, password) {
    return apiFetch('/auth/register', {
        method: 'POST',
        body: JSON.stringify({ name, email, password })
    });
}

/** FR-02: Login */
async function apiLogin(email, password) {
    return apiFetch('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password })
    });
}

// ── Reports API ───────────────────────────────────────────────────────

/** FR-03: Submit a report (with optional image) */
async function apiSubmitReport(data, imageFile) {
    const form = new FormData();
    form.append('incidentType', data.incidentType);
    form.append('description',  data.description);
    form.append('location',     data.location);
    if (data.latitude)  form.append('latitude',  data.latitude);
    if (data.longitude) form.append('longitude', data.longitude);
    if (data.priority)  form.append('priority',  data.priority);
    if (imageFile)      form.append('image', imageFile);

    return apiFormFetch('/reports', form);
}

/** FR-04: Get current user's reports */
async function apiGetMyReports() {
    return apiFetch('/reports/my');
}

/** Get a single report */
async function apiGetReport(id) {
    return apiFetch(`/reports/${id}`);
}

// ── Admin API ─────────────────────────────────────────────────────────

/** FR-05: Get all reports (admin) */
async function apiGetAllReports(status) {
    const qs = status ? `?status=${status}` : '';
    return apiFetch(`/admin/reports${qs}`);
}

/** FR-06: Update report status/priority/validity */
async function apiUpdateReport(reportId, updates) {
    return apiFetch(`/admin/reports/${reportId}`, {
        method: 'PUT',
        body: JSON.stringify(updates)
    });
}

/** Get admin dashboard stats */
async function apiGetStats() {
    return apiFetch('/admin/dashboard/stats');
}

// ── Certificates API ──────────────────────────────────────────────────

/** FR-09: Get current user's certificates */
async function apiGetMyCertificates() {
    return apiFetch('/certificates/my');
}

/** Get points + certificate summary */
async function apiGetSummary() {
    return apiFetch('/certificates/my/summary');
}

/** Verify a certificate by ID (public) */
async function apiVerifyCert(certId) {
    return apiFetch(`/certificates/verify/${certId}`);
}

// ── Session Management ────────────────────────────────────────────────

/** Save auth data after login/register */
function saveSession(data) {
    localStorage.setItem('ecoreport_token', data.token);
    localStorage.setItem('ecoreport_user', JSON.stringify({
        userId:      data.userId,
        name:        data.name,
        email:       data.email,
        role:        data.role,
        totalPoints: data.totalPoints
    }));
}

/** Clear session and redirect to login */
function logout() {
    localStorage.removeItem('ecoreport_token');
    localStorage.removeItem('ecoreport_user');
    window.location.href = '/pages/login.html';
}

/** Require authentication – redirect if not logged in */
function requireAuth() {
    if (!isAuthenticated()) {
        window.location.href = '/pages/login.html';
        return false;
    }
    return true;
}

/** Require admin role */
function requireAdmin() {
    if (!isAuthenticated() || !isAdmin()) {
        window.location.href = '/index.html';
        return false;
    }
    return true;
}
