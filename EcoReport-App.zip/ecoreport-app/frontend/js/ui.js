/**
 * ui.js – shared UI utility functions used across all pages.
 */

/** Render the navbar based on auth state */
function renderNavbar(activePage = '') {
    const user = getCurrentUser();
    const navEl = document.getElementById('navbar');
    if (!navEl) return;

    const links = user ? [
        { href: '/index.html',              label: 'Home',      page: 'home' },
        { href: '/pages/report.html',       label: 'Report',    page: 'report' },
        { href: '/pages/dashboard.html',    label: 'Dashboard', page: 'dashboard' },
        { href: '/pages/rewards.html',      label: 'Rewards',   page: 'rewards' },
        ...(user.role === 'ADMIN' ? [{ href: '/pages/admin.html', label: 'Admin', page: 'admin' }] : [])
    ] : [
        { href: '/index.html',        label: 'Home',     page: 'home' },
        { href: '/pages/login.html',  label: 'Login',    page: 'login' },
        { href: '/pages/login.html',  label: 'Register', page: 'register' }
    ];

    const linksHtml = links.map(l =>
        `<a href="${l.href}" class="nav-link${activePage === l.page ? ' active' : ''}">${l.label}</a>`
    ).join('');

    const authHtml = user
        ? `<div class="flex items-center gap-2">
             <span style="color:rgba(255,255,255,0.85);font-size:13px">${user.name}</span>
             <button onclick="logout()" class="btn btn-white" style="font-size:12px;padding:5px 12px">Logout</button>
           </div>`
        : `<a href="/pages/login.html" class="btn btn-white" style="font-size:12px;padding:5px 14px">Login</a>`;

    navEl.innerHTML = `
        <a href="/index.html" class="nav-brand">
            <div class="nav-logo">🌿</div>
            EcoReport
        </a>
        <div class="nav-links">${linksHtml}</div>
        <div>${authHtml}</div>
    `;
}

/** Show a toast/alert message */
function showAlert(message, type = 'success', containerId = 'alert-container') {
    const el = document.getElementById(containerId);
    if (!el) return;

    const icons = { success: '✓', error: '✗', info: 'ℹ', warning: '⚠' };
    el.innerHTML = `<div class="alert alert-${type}">${icons[type] || ''} ${message}</div>`;
    el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

    if (type === 'success') {
        setTimeout(() => { el.innerHTML = ''; }, 5000);
    }
}

/** Format a status string to a badge */
function statusBadge(status) {
    const map = {
        'PENDING':     'pending',
        'IN_PROGRESS': 'progress',
        'RESOLVED':    'resolved'
    };
    const labels = {
        'PENDING':     'Pending',
        'IN_PROGRESS': 'In Progress',
        'RESOLVED':    'Resolved'
    };
    const cls = map[status] || 'pending';
    return `<span class="badge badge-${cls}">${labels[status] || status}</span>`;
}

/** Format priority to a badge */
function priorityBadge(priority) {
    const map = { 'URGENT': 'urgent', 'HIGH': 'high', 'MEDIUM': 'medium', 'LOW': 'low' };
    return `<span class="badge badge-${map[priority] || 'medium'}">${priority}</span>`;
}

/** Format incident type to readable label */
function formatType(type) {
    const map = {
        'WATER_LEAK':     '💧 Water Leak',
        'FIRE_HAZARD':    '🔥 Fire Hazard',
        'INFRASTRUCTURE': '🏗️ Infrastructure',
        'OTHER':          '📋 Other'
    };
    return map[type] || type;
}

/** Format ISO datetime to readable string */
function formatDate(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

/** Show a loading spinner in an element */
function setLoading(elementId, isLoading) {
    const el = document.getElementById(elementId);
    if (!el) return;
    el.disabled = isLoading;
    el.innerHTML = isLoading
        ? '<span style="display:inline-block;animation:spin 1s linear infinite">⟳</span> Loading...'
        : el.dataset.originalText || 'Submit';
}

/** Simple form validation */
function validateForm(fields) {
    let valid = true;
    fields.forEach(({ id, min, max, message }) => {
        const el = document.getElementById(id);
        const errEl = document.getElementById(id + '-error');
        if (!el) return;
        const val = el.value.trim();
        const ok = val.length >= (min || 1) && val.length <= (max || 9999);
        if (errEl) {
            errEl.style.display = ok ? 'none' : 'block';
            errEl.textContent = message || 'This field is required';
        }
        if (!ok) valid = false;
    });
    return valid;
}
