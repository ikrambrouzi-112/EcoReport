# 🌿 EcoReport – Public Infrastructure & Fire Incident Reporting System

> Software Engineering Project · Al Akhawayn University · Province of Ifrane

A full-stack web application enabling citizens of the Province of Ifrane to report water leaks, fire hazards, and infrastructure incidents.

---

## 🏗️ Architecture

```
ecoreport/
├── backend/                 # Spring Boot REST API (Java 17)
│   └── src/main/java/com/ecoreport/
│       ├── controller/      # REST endpoints (MVC Pattern)
│       ├── service/         # Business logic layer
│       ├── repository/      # Data access layer (Repository Pattern)
│       ├── model/           # JPA entities (User, Report, Certificate)
│       ├── security/        # JWT authentication
│       └── config/          # Spring Security + CORS config
│
└── frontend/                # Vanilla HTML/CSS/JavaScript
    ├── index.html           # Landing / Home page
    ├── css/styles.css       # Global stylesheet
    ├── js/
    │   ├── api.js           # All API calls (centralized)
    │   └── ui.js            # Shared UI utilities
    └── pages/
        ├── login.html       # Login & Register (FR-01, FR-02)
        ├── report.html      # Submit Report + Leaflet map (FR-03)
        ├── dashboard.html   # User dashboard (FR-04)
        ├── admin.html       # Admin dashboard (FR-05, FR-06, FR-07)
        ├── rewards.html     # Points & Certificates (FR-08, FR-09)
        └── verify.html      # Certificate QR verification
```

---

## ⚙️ Design Patterns Used

| Pattern | Where Applied |
|---|---|
| **MVC** | `@RestController` (C), JPA Entities (M), HTML/JS Pages (V) |
| **Repository** | `UserRepository`, `ReportRepository`, `CertificateRepository` |
| **Observer/Event** | `PointsService` triggered when report is validated |
| **Layered Architecture** | Presentation → Controller → Service → Repository → DB |
| **DTO** | Separate request/response objects from domain entities |

---

## 🚀 Quick Start

### Prerequisites
- Java 17+
- Maven 3.8+
- MySQL 8+
- Any web server for frontend (e.g. VSCode Live Server)

### 1. Database Setup

```sql
-- Run the init script
mysql -u root -p < backend/src/main/resources/db/migration/V1__init.sql
```

### 2. Configure Database

Edit `backend/src/main/resources/application.properties`:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/ecoreport_db
spring.datasource.username=root
spring.datasource.password=YOUR_PASSWORD
```

### 3. Run Backend

```bash
cd backend
mvn spring-boot:run
```

Backend starts at **http://localhost:8080**

### 4. Run Frontend

Open `frontend/index.html` in a browser, or use Live Server:

```bash
# With Python
cd frontend
python -m http.server 3000
# then open http://localhost:3000
```

---

## 🔐 Demo Credentials

| Role | Email | Password |
|---|---|---|
| Admin | admin@ifrane.ma | admin123 |
| Citizen | sarah@example.com | admin123 |

---

## 📡 API Endpoints

| Method | Route | Auth | Description |
|---|---|---|---|
| POST | `/api/auth/register` | Public | FR-01: Register |
| POST | `/api/auth/login` | Public | FR-02: Login |
| POST | `/api/reports` | Citizen | FR-03: Submit report |
| GET | `/api/reports/my` | Citizen | FR-04: My reports |
| GET | `/api/admin/reports` | Admin | FR-05: All reports |
| PUT | `/api/admin/reports/{id}` | Admin | FR-06: Update status |
| GET | `/api/admin/dashboard/stats` | Admin | Dashboard KPIs |
| GET | `/api/certificates/my` | Citizen | FR-09: My certs |
| GET | `/api/certificates/verify/{id}` | Public | QR verification |

---

## 🎯 Functional Requirements Coverage

| FR | Feature | Status |
|---|---|---|
| FR-01 | User Registration | ✅ |
| FR-02 | User Login (JWT) | ✅ |
| FR-03 | Submit Incident Report | ✅ |
| FR-04 | View Report Status | ✅ |
| FR-05 | Admin View Reports | ✅ |
| FR-06 | Update Report Status | ✅ |
| FR-07 | Prioritize Urgent Reports | ✅ |
| FR-08 | Points Assignment System | ✅ |
| FR-09 | View Points and Certificates | ✅ |
| FR-10 | Location Validation (Ifrane boundary) | ✅ |

---

## 🛠️ Tech Stack

**Backend:** Java 17, Spring Boot 3, Spring Security, Spring Data JPA  
**Database:** MySQL 8, Hibernate ORM  
**Security:** JWT (jjwt), BCrypt password hashing, RBAC  
**Frontend:** HTML5, CSS3, Vanilla JavaScript, Leaflet.js  
**Tools:** Maven, Git, Figma, Postman  

---

## 👥 Team

- Lalla Ibtihal Jerboui
- Ikram El Brouzi
- Oumaima Dehmane

*Software Engineering Course · Al Akhawayn University*
